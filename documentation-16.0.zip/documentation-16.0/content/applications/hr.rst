:nosearch:

===============
Human resources
===============

.. toctree::

   hr/attendances
   hr/employees
   hr/payroll
