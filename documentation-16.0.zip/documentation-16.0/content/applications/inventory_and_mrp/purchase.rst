:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

========
Purchase
========

**Odoo Purchase** helps you keep track of purchase agreements, quotations, and purchase orders.
Learn how to keep track of purchase tender, automate replenishments and follow up on your orders.

.. seealso::
   - `Odoo Tutorials: Purchase <https://www.odoo.com/slides/purchase-23>`_

.. toctree::
   :titlesonly:

   purchase/products
   purchase/manage_deals
   purchase/advanced
