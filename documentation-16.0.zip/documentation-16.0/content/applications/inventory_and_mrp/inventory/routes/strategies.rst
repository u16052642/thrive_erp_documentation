:nosearch:

============================
Putaway & Removal Strategies
============================

.. toctree::
   :titlesonly:
   :glob:

   strategies/putaway
   strategies/removal
