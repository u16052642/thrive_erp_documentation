:nosearch:

=====
Setup
=====

.. toctree::
   :titlesonly:
   :glob:

   setup/hardware
   setup/software
