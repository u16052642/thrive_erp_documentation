==============================
Create a Transfer from Scratch
==============================

To create a transfer from the *Barcode* application, you first need to
print the operation type barcodes. To do so, you can download the
*Stock barcode sheet* from the home page of the app.

.. image:: transfers_scratch/transfers_scratch_01.png
    :align: center

Once done, you can scan the one for which you want to create a new
document. Then, an empty document will be created and you will be able
to scan your products to populate it.

.. image:: transfers_scratch/transfers_scratch_02.png
    :align: center
