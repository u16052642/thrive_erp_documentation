:nosearch:

================
Daily Operations
================

.. toctree::
   :titlesonly:
   :glob:

   operations/adjustments
   operations/internal
   operations/transfers_scratch
   operations/barcode_nomenclature
