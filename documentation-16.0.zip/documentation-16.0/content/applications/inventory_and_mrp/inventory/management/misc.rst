:nosearch:

========================
Miscellaneous Operations
========================

.. toctree::
   :titlesonly:
   :glob:

   misc/owned_stock
   misc/batch_transfers
   misc/wave_transfers
