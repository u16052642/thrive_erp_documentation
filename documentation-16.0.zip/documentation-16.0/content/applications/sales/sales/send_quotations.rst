:nosearch:

===============
Send Quotations
===============

.. toctree::
   :titlesonly:

   send_quotations/quote_template
   send_quotations/optional_products
   send_quotations/get_signature_to_validate
   send_quotations/get_paid_to_validate
   send_quotations/deadline
   send_quotations/orders_and_variants
