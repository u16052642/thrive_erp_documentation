:nosearch:

=============
Shop features
=============

.. toctree::
   :titlesonly:

   shop/sales_order
   shop/barcode
   shop/serial_numbers
