:nosearch:

================
Pricing features
================

.. toctree::
   :titlesonly:

   pricing/discounts
   pricing/discount_tags
   pricing/loyalty
   pricing/pricelists
   pricing/fiscal_position
   pricing/cash_rounding
