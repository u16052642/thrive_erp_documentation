=========
Reporting
=========

View statistics
===============

To access your statistics, go to :menuselection:`Point of Sale --> Reporting --> Orders`. Or, from
the **POS dashboard**, click the vertical ellipsis (:guilabel:`⋮`) button, :guilabel:`Reporting`,
and :guilabel:`Orders`.

These statistics are available in a graph or pivot view that you can filter or group depending on
your needs.
