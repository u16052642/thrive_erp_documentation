:nosearch:

===================
Analyze performance
===================

.. toctree::
   :titlesonly:

   performance/win_loss
   performance/google_spreadsheets
