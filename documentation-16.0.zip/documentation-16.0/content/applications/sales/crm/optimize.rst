:nosearch:

=============================
Optimize your Day-to-Day work
=============================

.. toctree::
   :titlesonly:

   optimize/partner_autocomplete
   optimize/gamification
