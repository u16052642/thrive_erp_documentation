:nosearch:

=====================
Organize the pipeline
=====================

.. toctree::
   :titlesonly:

   ../../productivity/discuss/overview/plan_activities
   pipeline/lost_opportunities
   pipeline/multi_sales_team
