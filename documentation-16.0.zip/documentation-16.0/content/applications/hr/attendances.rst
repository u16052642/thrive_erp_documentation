:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

===========
Attendances
===========

**Odoo Attendances** functions as a time clock. Employees check in and check out of work, while
managers can see who is available at any given time.

.. seealso::
   `Odoo Tutorials: Attendances <https://www.odoo.com/slides/slide/attendances-684>`_

.. toctree::
   :titlesonly:

   attendances/hardware
