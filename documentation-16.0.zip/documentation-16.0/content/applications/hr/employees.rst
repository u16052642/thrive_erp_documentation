:nosearch:
:show-content:
:show-toc:

=========
Employees
=========

Odoo *Employees* organizes a company's employee records, contracts, and departments.

.. toctree::
   :titlesonly:

   employees/new_employee
