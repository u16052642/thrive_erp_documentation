:nosearch:

=======
Devices
=======

.. toctree::
   :titlesonly:
   :glob:

   devices/screen
   devices/measurement_tool
   devices/camera
   devices/footswitch
   devices/printer
   devices/scale
