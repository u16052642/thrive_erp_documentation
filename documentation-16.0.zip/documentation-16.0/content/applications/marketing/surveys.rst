:nosearch:

=======
Surveys
=======

.. seealso::
   - `Odoo Tutorials: Surveys <https://www.odoo.com/slides/surveys-62>`_

.. toctree::
   :titlesonly:

   surveys/create
   surveys/scoring
   surveys/time_random
