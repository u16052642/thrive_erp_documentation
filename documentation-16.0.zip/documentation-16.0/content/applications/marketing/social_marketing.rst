:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

================
Social Marketing
================

.. seealso::
   - `Odoo Tutorials: Marketing <https://www.odoo.com/slides/marketing-27>`_

.. toctree::
   :titlesonly:

   social_marketing/essentials
