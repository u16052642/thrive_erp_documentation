:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

=============
SMS Marketing
=============

.. seealso::
   - `Odoo Tutorials: Marketing <https://www.odoo.com/slides/marketing-27>`_

.. toctree::
   :titlesonly:

   sms_marketing/essentials
   sms_marketing/pricing
