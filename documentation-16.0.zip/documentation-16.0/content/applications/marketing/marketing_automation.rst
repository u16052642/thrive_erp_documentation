:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

====================
Marketing Automation
====================

.. seealso::
   - `Odoo Tutorials: Marketing <https://www.odoo.com/slides/marketing-27>`_

.. toctree::
   :titlesonly:

   marketing_automation/getting_started
   marketing_automation/advanced
