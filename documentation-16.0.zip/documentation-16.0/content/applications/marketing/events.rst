:nosearch:

======
Events
======

.. seealso::
   - `Odoo Tutorials: Events <https://www.odoo.com/slides/surveys-63>`_

.. toctree::

   events/event_essentials
   events/sell_tickets
   events/track_manage_talks
