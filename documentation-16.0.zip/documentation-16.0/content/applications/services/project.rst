:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

=======
Project
=======

Odoo Project is a tool to manage your ongoing projects. Schedule tasks, assign activities to
coworkers, and keep track of each project's profitability.

.. seealso::
   `Odoo Tutorials: Project and Timesheets <https://www.odoo.com/slides/project-and-timesheets-21>`_

.. toctree::
   :titlesonly:

   project/tasks
   project/project_management
