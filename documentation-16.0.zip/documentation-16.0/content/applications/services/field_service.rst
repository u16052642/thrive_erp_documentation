:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

=============
Field Service
=============

.. seealso::
   - `Odoo Tutorials: Field Service <https://www.odoo.com/slides/field-service-49>`_

.. toctree::
   :titlesonly:

   field_service/onsite_interventions
   field_service/default_warehouse
