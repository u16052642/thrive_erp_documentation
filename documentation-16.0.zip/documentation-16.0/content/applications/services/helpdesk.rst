:nosearch:
:show-content:
:hide-page-toc:
:show-toc:

========
Helpdesk
========

.. seealso::
   - `Odoo Tutorials: Helpdesk <https://www.odoo.com/slides/helpdesk-51>`_

.. toctree::
   :titlesonly:

   helpdesk/overview
   helpdesk/advanced
