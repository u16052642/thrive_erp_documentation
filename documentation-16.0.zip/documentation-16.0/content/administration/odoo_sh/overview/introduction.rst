=======================
Introduction to Odoo.sh
=======================

.. youtube:: QuNsa9n9PMg
    :align: right
    :width: 700
    :height: 394

The documentation will help you go live with your Odoo.sh project in no time.
