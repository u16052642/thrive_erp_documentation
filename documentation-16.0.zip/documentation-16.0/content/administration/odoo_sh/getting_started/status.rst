======
Status
======

Overview
========

The status page shows statistics regarding the servers your project uses. It includes the servers
availability.

.. image:: status/interface-status.png
   :align: center
